# Import the necessary libraries for reading csv files


# Set the path for the csv file


# Create new lists to store data for heaviest and tallest Pokemon


# Open the csv


    # Iterate through the data and search for the number the user inputted. Remember to skip the header of the CSV.



        # Print the name of the Pokemon(identifier) and Pokedex number(species id) at that number. For example, "Pokemon No. 25 - Pikachu".


        # Iterate through the data and search for Pokemon whose weight is greater than 3000. Append only the Pokemon's name and weight to the 'heaviest' list.


        # Iterate through the data and search for Pokemon whose height is greater than 50. Append only the Pokemon's name and height to the 'tallest' list.


# Print the list of heaviest and tallest pokemon
