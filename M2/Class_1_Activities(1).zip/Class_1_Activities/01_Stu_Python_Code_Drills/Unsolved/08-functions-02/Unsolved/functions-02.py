# Define a function "warble" that takes in a string as an argument, adds " arglebargle" to the end of it, and returns the result.


# Print the result of calling your "warble" function with the argument "hello".


# Define a function "wibble" that takes a string as an argument, prints the argument, prepends "wibbly " to the argument, and returns the result


# Print the result of calling your "wibble" function with the argument "bibbly"


# Define a function "print_sum" that takes in two numbers as arguments and prints the sum of those two numbers.


# Define a function "return_sum" that takes in two numbers as arguments and returns the sum of those two numbers


# Define a function "triple_sum" that takes in 3 arguments and returns the sum of those 3 numbers.


"""
Define a function "dance_party" that takes in a string as an argument,
then prints "dance!", then updates the string by calling "wibble" function
with that argument, followed by "warble" function with that argument,
then returns the updated stringdef dance_party(string_param):

"""

# Print the result of calling your "dance_party" function with your name as the argument
