# Variables and Lists

In this activity, you will get more practice declaring and manipulating variables and lists.

## Instructions

Open the [starter file](Unsolved/lists-01.py) and perform the following:

1. Create a list, `list_1`,  with `0`, `1`, `2`, `3` as values.

2. Create a list, `list_2` with `4`, `5`, `6`, `7` as values.

3. Create a list, `list_3` with `8`, `9`, `10`, `11` as values.

4. Print the 3rd index of `list_1`.

5. Print the 1st index of `list_2`.

6. Print the 2nd index of `list_3`.

---

© 2020 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
