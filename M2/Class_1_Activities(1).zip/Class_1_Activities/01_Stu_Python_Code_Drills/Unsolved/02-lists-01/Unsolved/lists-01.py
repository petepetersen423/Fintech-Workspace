# Create a list, `list_1`,  with `0`, `1`, `2`, `3` as values.
# YOUR CODE HERE!

# Create a list, `list_2` with `4`, `5`, `6`, `7` as values.
# YOUR CODE HERE!

# Create a list, `list_3` with `8`, `9`, `10`, `11` as values.
# YOUR CODE HERE!


# Print the 3rd index of `list_1`.
# YOUR CODE HERE!

# Print the 1st index of `list_2`.
# YOUR CODE HERE!

# Print the 2nd index of `list_3`.
# YOUR CODE HERE!
