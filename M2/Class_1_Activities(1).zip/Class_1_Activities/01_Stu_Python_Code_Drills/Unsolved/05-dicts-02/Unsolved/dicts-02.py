# Use the `from` keyword to import the `shows` dictionary from the `show_data.py` file
from show_data import shows


# QUESTION 1: Is the Walking Dead still running?
print(# YOUR CODE HERE!)

# QUESTION 2: Who hosts the Daily Show (talk)?
print(# YOUR CODE HERE!)

# QUESTION 3: Who does Will Arnett play in Arrested Development (comedy)
print(# YOUR CODE HERE!)

# QUESTION 4: Who does Peter Dinklage play in Game of Thrones (drama)?
print(# YOUR CODE HERE!)

# QUESTION 5: Who plays Dexter in Dexter (drama) and who plays Dexter in Dexter's Lab (kids)?
# HINT: You can print multiple items at once by using a comma like this: print(thing1, thing2)
print(# YOUR CODE HERE!)

# QUESTION 6: Who are the main characters of the Office (comedy) (not the actors, but the actual character names)?
# YOUR CODE HERE!

# QUESTION 7: List the main cast of Dexter (drama) (the actors, not the characters)
# YOUR CODE HERE!


# QUESTION : List the American Idol Judges
# YOUR CODE HERE!

# QUESTION 9: What are the show names of the Impractical Jokers (comedy)
# Hint: You will need to use a loop for this one. You may not simply log the entire list, but must log each name individually
# YOUR CODE HERE!
