# san_francisco = {
#     "has_multiple_bridges": True,
#     "state": "California",
#     "tallest_building": "SalesForce Building",
#     "median_house_price": 1610000,
#     "notable_attractions": ["Alcatraz", "Golden Gate Bridge", "Fisherman's Wharf"],
# }

# Re-create the content of the commented out `san_francisco` dictionary by using bracket notation to manually add each of the key-value pairs (including nested objects).
san_francisco = {}

# YOUR CODE HERE!
# YOUR CODE HERE!
# YOUR CODE HERE!
# YOUR CODE HERE!
# YOUR CODE HERE!


# Print the manually modified `san_francisco` dictionary and confirm the contents match the commented out version.
print(san_francisco)
