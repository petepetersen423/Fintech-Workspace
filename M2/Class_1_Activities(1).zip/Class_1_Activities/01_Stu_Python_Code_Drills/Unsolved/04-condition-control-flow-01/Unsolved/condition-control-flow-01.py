
# Declare a variable budget and assign it a value of 5000.
budget = # YOUR CODE HERE!

# Declare a variable rent_cost and assign it a value of 1500.
rent_cost = # YOUR CODE HERE!

# Declare a variable utilities_cost and assign it a value of 150.
utilities_cost = # YOUR CODE HERE!

# Declare a variable food_cost and assign it a value of 250.
food_cost = # YOUR CODE HERE!

# Declare a variable transportation_cost and assign it a value of 350.
transportation_cost = # YOUR CODE HERE!

# Declare a variable computer_cost and assign it a value of 2000.
computer_cost = # YOUR CODE HERE!

# Declare a variable called total_cost that takes the sum of all costs above (excluding budget).
# YOUR CODE HERE!


# Write an if statement that checks whether the sum of all our costs is within the budget.
# If so, print "You're total cost is " concatenated with the `total_cost` variable.
# Else, print "You're over budget by " concatenated with the difference between `budget` and `total_cost`.
# YOUR CODE HERE!


# Write an if statement that checks whether the rent_cost is larger than the sum of the `utilities_cost`, `food_cost`,
# and `transportation_cost`. If so, print a string that says "The rent is too darn high!".
# Else, print a string that says "Ahhh just right!"
# YOUR CODE HERE!
