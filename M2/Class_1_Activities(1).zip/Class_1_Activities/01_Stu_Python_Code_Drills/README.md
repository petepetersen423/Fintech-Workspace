# Python Code Drills


## Instructions

Learning to code takes practice. Coding drills like the ones included in this Unsolved folder help to provide that practice.

Over the next 20 minutes, work to complete as many of these code drills as possible. Instructions are provided in each of the code drill activity folders.

---

© 2021 Trilogy Education Services, a 2U, Inc. brand. All Rights Reserved.
