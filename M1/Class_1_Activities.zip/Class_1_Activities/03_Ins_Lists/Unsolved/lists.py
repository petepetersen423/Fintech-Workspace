# -*- coding: utf-8 -*-
"""Instructor Demo: Lists.

This script showcases basic operations of Python Lists.
"""
