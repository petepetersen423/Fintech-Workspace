# Create variables

# Print the variables

# Prints the data type of each declared variable

# Using variable names in calculations

# Updating variables using assignment

# Substituting/formatting variable

# Two number values will be added

# Two string values will be concatenated

# Variable naming conventions
